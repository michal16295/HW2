package game.enums;

/**
 * Created by itzhak on 09-Mar-19.
 */
public enum WeatherCondition {
    SUNNY,
    CLOUDY,
    STORMY
}
